# Changelog

## v1.3 – Selective The Hindu news
- Replaced the India-only RSS stream with three user-selectable feeds: Science, World/International, and Home/Top Stories. Top Stories is deliberately not described as the printed newspaper's actual Page One.
- Added checkboxes in the app configuration screen, default all selected. Category-only changes do not require city lookup.
- Fetches selected sections only, fairly interleaves and deduplicates up to 12 headlines, and labels each in the rotating widget.
- Cancels RSS polling when all sections are disabled, preserves successful feed results if another section fails, and filters old cache entries by selection.
- Preserved weather, AQI, precipitation, sky widget, Quick Settings and status-bar icons.

## v1.2 – The Hindu weather-and-news widget
- Added optional 4×2 Weather + Headlines widget with existing Open-Meteo temperature, icon and city, plus a rotating The Hindu India RSS headline strip.
- Added isolated 30-minute JobScheduler RSS updates, capped on-device headline/link/date cache, publisher-only HTTPS link validation, no extra libraries and no full article copying.
- Added collection-capable AdapterViewFlipper with modern `RemoteCollectionItems` on Android 12+ and RemoteViewsService fallback on Android 8–11.
- Preserved the five original weather/AQI/rain/sky widgets and Quick Settings weather status icons.
- Modernized GitHub build workflow to work with the uploaded ZIP and existing Android SDK, avoiding the retired `tools` package.


## v1.1.1 – Revised user temperature ranges
- Updated the status-bar icon thresholds to the user-requested mapping: ≤0°C bundled-up person, 1–7°C two snowflakes, 8–13°C one snowflake, 14–20°C sun/cloud, 21–27°C simple thermometer, 28–33°C simple thermometer fallback, 34–38°C sweating person, ≥39°C red hot flame.
- Resolved the overlap between “0°C and below” and “0–7°C” by interpreting them as `≤0°C` and `1–7°C`.
- Kept thunderstorm and rain icons as higher-priority condition overrides.

## v1.1 – Condition-aware status bar icons
- Replaced numeric glyph (`27°`) with exactly one condition/temperature icon from the nine uploaded user images.
- Added white/transparent, density-specific 24/36/48/72/96 px status bar assets, and full-color artwork for the notification drawer.
- Mapped Open-Meteo weather codes to precipitation/storm/cold/hot categories, with bad weather taking priority over comfort temperature.
- Fahrenheit-aware numeric thresholds (defined in °C), and status-bar icons refreshed from the existing weather cache with no additional weather polling.
- Updated the Quick Settings tile icon to match the status icon and preserved its on/off semantics and notification permission handling.
- Original uploaded filenames containing thresholds were not retained by the attachment system. Current default thresholds are documented in README and editable in WeatherStatusIcons.java.

## v1.0 – Widget pack / Quick Settings tile
- Five home-screen widgets: compact weather, four-hour forecast, US AQI, six-hour precipitation, sun/moon sky arcs.
- Toggleable Quick Settings temperature icon and battery-friendly shared weather updates.

package com.overcast.mini;

import android.content.Context;
import android.content.SharedPreferences;

/** Explicit, per-app RSS category selection. No tracking, keys, or personalisation. */
public final class NewsCategories {
    public static final int SCIENCE = 1;
    public static final int WORLD = 2;
    public static final int TOP_STORIES = 4;
    public static final int ALL = SCIENCE | WORLD | TOP_STORIES;
    private static final String PREFS = "overcast_headlines";
    private static final String SELECTED = "selected_sections_v2";

    private NewsCategories() { }

    public static int selected(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getInt(SELECTED, ALL) & ALL;
    }

    /** Return true only if preferences actually changed. */
    public static boolean save(Context context, int selection) {
        selection &= ALL;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (prefs.getInt(SELECTED, ALL) == selection) return false;
        prefs.edit().putInt(SELECTED, selection).apply();
        return true;
    }

    public static String label(int category) {
        switch (category) {
            case SCIENCE: return "Science";
            case WORLD: return "World";
            case TOP_STORIES: return "Top Stories";
            default: return "News";
        }
    }
}

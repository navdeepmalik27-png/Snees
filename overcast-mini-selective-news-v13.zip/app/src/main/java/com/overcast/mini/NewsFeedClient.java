package com.overcast.mini;

import android.text.Html;
import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/** Read-only headline importer. No scraping, subscription bypass, or article-body storage. */
public final class NewsFeedClient {
    private static final String SCIENCE_URL =
            "https://www.thehindu.com/sci-tech/science/feeder/default.rss";
    private static final String WORLD_URL =
            "https://www.thehindu.com/news/international/feeder/default.rss";
    // This is the publisher's HOME feed, not its verified print-edition front page.
    private static final String TOP_STORIES_URL =
            "https://www.thehindu.com/feeder/default.rss";
    public static final int MAX_ITEMS = 12;
    private static final int MAX_PER_FEED = 12;
    private NewsFeedClient() { }

    public static final class Headline {
        public final String title, url;
        public final long publishedMs;
        public final int category;
        public Headline(String title, String url, long publishedMs, int category) {
            this.title = title;
            this.url = url;
            this.publishedMs = publishedMs;
            this.category = category;
        }
    }

    /** Fetch only selected categories, and interleave them so one busy feed doesn't dominate. */
    public static ArrayList<Headline> fetchSelected(int mask) throws Exception {
        mask &= NewsCategories.ALL;
        ArrayList<ArrayList<Headline>> feeds = new ArrayList<>();
        if ((mask & NewsCategories.SCIENCE) != 0) fetchSafely(SCIENCE_URL, NewsCategories.SCIENCE, feeds);
        if ((mask & NewsCategories.WORLD) != 0) fetchSafely(WORLD_URL, NewsCategories.WORLD, feeds);
        if ((mask & NewsCategories.TOP_STORIES) != 0)
            fetchSafely(TOP_STORIES_URL, NewsCategories.TOP_STORIES, feeds);
        if (feeds.isEmpty()) throw new IOException("All selected RSS feeds failed or returned no headlines");
        return interleave(feeds);
    }

    /** Fair rotation across chosen sections; a duplicate from Home appears only once. */
    static ArrayList<Headline> interleave(ArrayList<ArrayList<Headline>> feeds) {
        ArrayList<Headline> combined = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int row = 0; combined.size() < MAX_ITEMS && row < MAX_PER_FEED; row++) {
            boolean hadMore = false;
            for (List<Headline> feed : feeds) {
                if (row < feed.size()) {
                    hadMore = true;
                    Headline item = feed.get(row);
                    if (seen.add(item.url)) combined.add(item);
                    if (combined.size() == MAX_ITEMS) break;
                }
            }
            if (!hadMore) break;
        }
        return combined;
    }

    private static void fetchSafely(String url, int category, ArrayList<ArrayList<Headline>> feeds) {
        try {
            ArrayList<Headline> headlines = fetchOne(url, category);
            if (!headlines.isEmpty()) feeds.add(headlines);
        } catch (Exception e) {
            android.util.Log.w("OvercastRSS", "Selected section "
                    + NewsCategories.label(category) + " could not refresh", e);
        }
    }

    static ArrayList<Headline> fetchOne(String source, int category) throws Exception {
        HttpURLConnection conn = openPublisherConnection(source);
        try {
            try (InputStream in = conn.getInputStream()) {
                return parseFeed(in, category);
            }
        } finally {
            conn.disconnect();
        }
    }

    /** Testable, streaming parser: rejects non-publisher links and stores only title/date/URL. */
    static ArrayList<Headline> parseFeed(InputStream in, int category) throws Exception {
        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(in, "UTF-8");
        ArrayList<Headline> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        boolean inItem = false;
        String title = null, link = null, date = null;
        int event;
        int examined = 0;
        while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                String tag = parser.getName();
                if ("item".equalsIgnoreCase(tag)) {
                    inItem = true;
                    title = link = date = null;
                } else if (inItem) {
                    if ("title".equalsIgnoreCase(tag)) title = parser.nextText();
                    else if ("link".equalsIgnoreCase(tag)) link = parser.nextText();
                    else if ("pubDate".equalsIgnoreCase(tag)) date = parser.nextText();
                }
            } else if (event == XmlPullParser.END_TAG
                    && "item".equalsIgnoreCase(parser.getName()) && inItem) {
                inItem = false;
                if (++examined > 100) break;
                if (title != null && link != null) {
                    String cleanTitle = Html.fromHtml(title, Html.FROM_HTML_MODE_LEGACY)
                            .toString().replaceAll("\\s+", " ").trim();
                    if (cleanTitle.length() > 240) cleanTitle = cleanTitle.substring(0, 240);
                    String cleanLink = link.trim();
                    if (!cleanTitle.isEmpty() && isPublisherLink(cleanLink)
                            && seen.add(cleanLink)) {
                        out.add(new Headline(cleanTitle, cleanLink, parseDate(date), category));
                        if (out.size() >= MAX_PER_FEED) break;
                    }
                }
            }
        }
        return out;
    }

    /** Follow at most three redirects, accepting only HTTPS The Hindu destinations. */
    private static HttpURLConnection openPublisherConnection(String source) throws Exception {
        URL current = new URL(source);
        for (int hop = 0; hop < 4; hop++) {
            HttpURLConnection conn = (HttpURLConnection) current.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(12000);
            conn.setInstanceFollowRedirects(false);
            conn.setRequestProperty("User-Agent", "OvercastMini/1.3 (RSS weather-news widget)");
            conn.setRequestProperty("Accept",
                    "application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.2");
            conn.setRequestProperty("Accept-Encoding", "identity");
            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_MOVED_PERM
                    || code == HttpURLConnection.HTTP_MOVED_TEMP
                    || code == HttpURLConnection.HTTP_SEE_OTHER || code == 307 || code == 308) {
                String destination = conn.getHeaderField("Location");
                conn.disconnect();
                if (destination == null) throw new IOException("RSS redirect without destination");
                current = new URL(current, destination);
                if (!isPublisherLink(current.toString()))
                    throw new IOException("RSS redirected outside publisher");
                continue;
            }
            if (code != HttpURLConnection.HTTP_OK) {
                conn.disconnect();
                throw new IOException("RSS HTTP " + code);
            }
            return conn;
        }
        throw new IOException("Too many RSS redirects");
    }

    /** Reject third-party / javascript links from feed content. */
    public static boolean isPublisherLink(String value) {
        if (value == null) return false;
        try {
            java.net.URI uri = new java.net.URI(value);
            String host = uri.getHost();
            return "https".equalsIgnoreCase(uri.getScheme())
                    && host != null && (host.equalsIgnoreCase("thehindu.com")
                    || host.toLowerCase(Locale.US).endsWith(".thehindu.com"));
        } catch (Exception ignored) {
            return false;
        }
    }

    private static long parseDate(String date) {
        if (date == null || date.isEmpty()) return 0L;
        String[] formats = {"EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm Z",
                "dd MMM yyyy HH:mm:ss Z"};
        for (String format : formats) {
            try {
                SimpleDateFormat df = new SimpleDateFormat(format, Locale.US);
                df.setLenient(true);
                df.setTimeZone(TimeZone.getTimeZone("GMT"));
                Date parsed = df.parse(date.trim());
                if (parsed != null) return parsed.getTime();
            } catch (Exception ignored) { }
        }
        return 0L;
    }
}

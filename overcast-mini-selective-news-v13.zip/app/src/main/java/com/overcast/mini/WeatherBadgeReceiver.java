package com.overcast.mini;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Notification action for immediately stopping the status-bar temperature display. */
public final class WeatherBadgeReceiver extends BroadcastReceiver {
    public static final String ACTION_OFF = "com.overcast.mini.ACTION_BADGE_OFF";

    @Override public void onReceive(Context context, Intent intent) {
        if (!ACTION_OFF.equals(intent.getAction())) return;
        WeatherPrefs.setTemperatureBadgeEnabled(context, false);
        WeatherStatusManager.sync(context);
        WeatherTileService.requestRefresh(context);
        WeatherJobService.cancelWhenUnused(context);
    }
}

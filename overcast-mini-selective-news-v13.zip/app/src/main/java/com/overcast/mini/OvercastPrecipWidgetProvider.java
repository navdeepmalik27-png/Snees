package com.overcast.mini;

/** Standalone six-hour precipitation forecast widget. */
public final class OvercastPrecipWidgetProvider extends OvercastWidgetProvider { }

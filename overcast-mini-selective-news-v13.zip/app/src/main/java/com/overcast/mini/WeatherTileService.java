package com.overcast.mini;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Native swipe-down Weather Quick Settings toggle. */
public final class WeatherTileService extends TileService {
    public static final String EXTRA_REQUEST_NOTIFICATIONS = "request_temperature_notifications";

    @Override public void onStartListening() {
        super.onStartListening();
        renderTile();
    }

    @Override public void onTileAdded() {
        super.onTileAdded();
        renderTile();
    }

    @Override public void onTileRemoved() {
        super.onTileRemoved();
        WeatherPrefs.setTemperatureBadgeEnabled(this, false);
        WeatherStatusManager.sync(this);
        WeatherJobService.cancelWhenUnused(this);
    }

    @Override public void onClick() {
        super.onClick();
        if (!WeatherPrefs.hasLocation(this)) {
            openConfig(false);
            return;
        }
        boolean enabled = !WeatherPrefs.isTemperatureBadgeEnabled(this);
        WeatherPrefs.setTemperatureBadgeEnabled(this, enabled);
        if (enabled) {
            WeatherJobService.schedulePeriodic(this);
            long age = System.currentTimeMillis() - WeatherPrefs.getLastUpdatedMs(this);
            if (age > 30L * 60 * 1000) WeatherJobService.triggerNow(this, false);
        }
        WeatherStatusManager.sync(this);
        renderTile();
        if (enabled && !WeatherStatusManager.canNotify(this)) {
            // Android 13+ needs an Activity for the runtime notification permission dialog.
            openConfig(true);
        } else if (!enabled) {
            WeatherJobService.cancelWhenUnused(this);
        }
    }

    private void openConfig(boolean permissionRequest) {
        Intent config = new Intent(this, ConfigActivity.class);
        config.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (permissionRequest) config.putExtra(EXTRA_REQUEST_NOTIFICATIONS, true);
        if (Build.VERSION.SDK_INT >= 34) {
            PendingIntent pi = PendingIntent.getActivity(this, 83, config,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            startActivityAndCollapse(pi);
        } else {
            startActivityAndCollapse(config);
        }
    }

    private void renderTile() {
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean enabled = WeatherPrefs.isTemperatureBadgeEnabled(this);
        WeatherData data = WeatherData.parse(WeatherPrefs.getCachedJson(this));
        long age = System.currentTimeMillis() - WeatherPrefs.getLastUpdatedMs(this);
        boolean fresh = data != null && age >= 0 && age < 24L * 60 * 60 * 1000;
        String unit = WeatherPrefs.isFahrenheit(this) ? "°F" : "°C";
        String display = fresh ? (data.temp + unit) : "--";
        tile.setState(enabled ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel(fresh ? ("Weather " + display) : "Weather");
        tile.setIcon(Icon.createWithResource(this, fresh
                ? WeatherStatusIcons.smallIcon(WeatherStatusIcons.choose(
                        data.wmoCode, data.temp, WeatherPrefs.isFahrenheit(this)))
                : R.drawable.ic_status_mild_cloud_sun));
        if (Build.VERSION.SDK_INT >= 29) {
            tile.setSubtitle(enabled ? (!WeatherStatusManager.canNotify(this)
                    ? "Allow notifications" : (fresh ? "Status bar on" : "Waiting for weather"))
                    : "Off · Tap to show");
        }
        if (Build.VERSION.SDK_INT >= 30) {
            tile.setStateDescription(enabled ? "Weather status icon enabled" : "Weather status icon disabled");
        }
        tile.updateTile();
    }

    public static void requestRefresh(Context context) {
        try {
            TileService.requestListeningState(context,
                    new ComponentName(context, WeatherTileService.class));
        } catch (RuntimeException ignored) {
            // The tile is optional; onStartListening will refresh if the system hasn't added it yet.
        }
    }
}

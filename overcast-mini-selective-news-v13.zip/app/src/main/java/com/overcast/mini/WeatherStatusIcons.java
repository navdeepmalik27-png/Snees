package com.overcast.mini;

/**
 * Maps cached Open-Meteo conditions/temperature to exactly one of the nine
 * user-supplied status-bar illustrations. Thunderstorms and rain override
 * temperature categories. Thresholds are ALWAYS interpreted in Celsius,
 * regardless of the temperature display unit selected in the app.
 *
 * The tiny status-bar PNGs are WHITE/ALPHA masks, not colored images: Android
 * recolors small notification icons to match the user's system status bar.
 */
public final class WeatherStatusIcons {
    public enum Kind {
        STORM, RAIN, FREEZING, COLD_THERMOMETER, COLD_PERSON,
        MILD_CLOUD_SUN, HOT_THERMOMETER, HOT_FLAME, HOT_EXTREME
    }

    private WeatherStatusIcons() { }

    /** Precedence: thunder/hail > rain > temperature. */
    public static Kind choose(int wmoCode, double displayedTemperature, boolean isFahrenheit) {
        final double c = isFahrenheit
                ? (displayedTemperature - 32d) * (5d / 9d) : displayedTemperature;
        if (wmoCode >= 95 && wmoCode <= 99) return Kind.STORM;
        if ((wmoCode >= 51 && wmoCode <= 67)
                || (wmoCode >= 80 && wmoCode <= 82)) return Kind.RAIN;

        // User-requested temperature mapping:
        // <= 0°C   -> guy with meter (cold person)
        // 1–7°C    -> two snowflakes
        // 8–13°C   -> one snowflake
        // 14–20°C  -> cloud + sun
        // 21–27°C  -> simple thermometer
        // 28–33°C  -> simple thermometer (warm-but-not-extreme fallback chosen for the unspecified slot)
        // 34–38°C  -> sweating guy
        // >= 39°C  -> red hot flame icon
        if (c <= 0) return Kind.COLD_PERSON;
        if (c <= 7) return Kind.FREEZING;
        if (c <= 13) return Kind.COLD_THERMOMETER;
        if (c <= 20) return Kind.MILD_CLOUD_SUN;
        if (c <= 33) return Kind.HOT_THERMOMETER;
        if (c <= 38) return Kind.HOT_EXTREME;
        return Kind.HOT_FLAME;
    }

    public static int smallIcon(Kind kind) {
        switch (kind) {
            case STORM: return R.drawable.ic_status_storm;
            case RAIN: return R.drawable.ic_status_rain;
            case FREEZING: return R.drawable.ic_status_freezing;
            case COLD_THERMOMETER: return R.drawable.ic_status_cold_thermometer;
            case COLD_PERSON: return R.drawable.ic_status_cold_person;
            case HOT_THERMOMETER: return R.drawable.ic_status_hot_thermometer;
            case HOT_FLAME: return R.drawable.ic_status_hot_flame;
            case HOT_EXTREME: return R.drawable.ic_status_hot_extreme;
            default: return R.drawable.ic_status_mild_cloud_sun;
        }
    }

    public static int colorArtwork(Kind kind) {
        switch (kind) {
            case STORM: return R.drawable.ic_weather_art_storm;
            case RAIN: return R.drawable.ic_weather_art_rain;
            case FREEZING: return R.drawable.ic_weather_art_freezing;
            case COLD_THERMOMETER: return R.drawable.ic_weather_art_cold_thermometer;
            case COLD_PERSON: return R.drawable.ic_weather_art_cold_person;
            case HOT_THERMOMETER: return R.drawable.ic_weather_art_hot_thermometer;
            case HOT_FLAME: return R.drawable.ic_weather_art_hot_flame;
            case HOT_EXTREME: return R.drawable.ic_weather_art_hot_extreme;
            default: return R.drawable.ic_weather_art_mild_cloud_sun;
        }
    }
}

package com.overcast.mini;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.content.Context;

/** Small transient, density-independent illustrations for Android RemoteViews. */
public final class MiniCharts {
    private MiniCharts() {}

    private static Paint paint(int color, float size) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        return p;
    }

    public static Bitmap precipitation(Context context, WeatherData d) {
        int w = 672, h = 170;
        Bitmap out = Bitmap.createBitmap(480, 120, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.scale(480f / w, 120f / h);
        int ink = context.getColor(R.color.oc_on_surface_variant);
        int rain = context.getColor(R.color.oc_accent);
        Paint bar = paint(rain, 20);
        Paint text = paint(ink, 21);
        Paint faint = paint(ink & 0x44ffffff, 18);
        text.setTextAlign(Paint.Align.CENTER);
        faint.setTextAlign(Paint.Align.CENTER);
        Paint track = paint(rain, 20);
        track.setAlpha(34);
        for (int i = 0; i < d.rainHourCount; i++) {
            float center = 48 + i * 115;
            float maxHeight = 88;
            float chance = Math.max(0, Math.min(100, d.rainChances[i]));
            float filled = maxHeight * chance / 100f;
            c.drawRoundRect(center - 19, 34, center + 19, 34 + maxHeight, 13, 13, track);
            if (chance > 0) {
                c.drawRoundRect(center - 19, 34 + maxHeight - Math.max(4, filled),
                        center + 19, 34 + maxHeight, 12, 12, bar);
            }
            c.drawText(d.rainChances[i] + "%", center, 24, text);
            String hour = d.rainLabels[i] == null ? "--" : d.rainLabels[i];
            c.drawText(hour, center, 151, faint);
        }
        return out;
    }

    /** A full 24-hour sky altitude graph, not an azimuth/compass graph. */
    public static Bitmap sky(Context context, SkyTimeline timeline) {
        final int W = 700, H = 210;
        Bitmap out = Bitmap.createBitmap(560, 168, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.scale(560f / W, 168f / H);
        final float left = 24, right = W - 24, horizon = 146;
        int ink = context.getColor(R.color.oc_on_surface_variant);
        Paint grid = paint(ink, 18);
        grid.setAlpha(88);
        grid.setStrokeWidth(1.7f);
        c.drawLine(left, horizon, right, horizon, grid);
        Paint hour = paint(ink, 18);
        hour.setAlpha(180);
        hour.setTextAlign(Paint.Align.CENTER);
        for (int h = 0; h <= 24; h += 6) {
            float x = left + (right - left) * h / 24f;
            c.drawLine(x, horizon - 4, x, horizon + 4, grid);
            c.drawText(String.format(java.util.Locale.US, "%02d", h), x, H - 8, hour);
        }

        // A soft amber sunlight region above the horizon gives the chart its sky-arc look.
        Path dayFill = new Path();
        dayFill.moveTo(left, horizon);
        for (int i = 0; i < timeline.sunAltitudes.length; i++) {
            float x = left + (right - left) * i / (timeline.sunAltitudes.length - 1f);
            float y = yFor(Math.max(0, timeline.sunAltitudes[i]), horizon);
            dayFill.lineTo(x, y);
        }
        dayFill.lineTo(right, horizon);
        dayFill.close();
        Paint shade = paint(0xffefb254, 16);
        shade.setShader(new LinearGradient(0, 35, 0, horizon,
                new int[]{0x5aefa53a, 0x10efb254}, null, Shader.TileMode.CLAMP));
        c.drawPath(dayFill, shade);

        drawArc(c, timeline.sunAltitudes, left, right, horizon, 0xffe4a13a, false);
        drawArc(c, timeline.moonAltitudes, left, right, horizon, 0xff80aede, true);

        float nowX = left + (right - left) * (float) timeline.nowProgress;
        Paint nowLine = paint(ink, 16);
        nowLine.setAlpha(160);
        nowLine.setStyle(Paint.Style.STROKE);
        nowLine.setStrokeWidth(2);
        nowLine.setPathEffect(new DashPathEffect(new float[]{5, 5}, 0));
        c.drawLine(nowX, 14, nowX, horizon + 14, nowLine);
        Paint nowLabel = paint(ink, 17);
        nowLabel.setTextAlign(Paint.Align.CENTER);
        c.drawText("NOW", Math.max(left + 28, Math.min(right - 28, nowX)), 15, nowLabel);

        drawOrb(c, nowX, yFor(timeline.now.sun.altitude, horizon), 0xffefab3d,
                timeline.now.sun.altitude >= 0, false);
        drawOrb(c, nowX, yFor(timeline.now.moon.altitude, horizon), 0xff91bde5,
                timeline.now.moon.altitude >= 0, true);
        return out;
    }

    private static float yFor(double altitude, float horizon) {
        // Below-horizon bodies remain just under the baseline, not artificially above it.
        return altitude >= 0 ? horizon - (float) Math.min(115, altitude * 1.32)
                : horizon + (float) Math.min(22, -altitude * 0.36);
    }

    private static void drawArc(Canvas c, double[] alt, float left, float right,
                                float horizon, int color, boolean moon) {
        Paint line = paint(color, 18);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(moon ? 3.7f : 4.8f);
        line.setStrokeCap(Paint.Cap.ROUND);
        if (moon) line.setPathEffect(new DashPathEffect(new float[]{13, 8}, 0));
        Path path = new Path();
        for (int i = 0; i < alt.length; i++) {
            float x = left + (right - left) * i / (alt.length - 1f);
            float y = yFor(alt[i], horizon);
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        c.drawPath(path, line);
    }

    private static void drawOrb(Canvas c, float x, float y, int color, boolean visible, boolean moon) {
        Paint glow = paint(color, 14);
        glow.setAlpha(visible ? 58 : 22);
        c.drawCircle(x, y, moon ? 15 : 19, glow);
        Paint disk = paint(color, 14);
        disk.setAlpha(visible ? 255 : 140);
        c.drawCircle(x, y, moon ? 8.5f : 10, disk);
        if (moon) {
            Paint shine = paint(Color.WHITE, 14);
            shine.setAlpha(visible ? 220 : 120);
            c.drawCircle(x - 2, y - 2, 3.5f, shine);
        }
    }
}

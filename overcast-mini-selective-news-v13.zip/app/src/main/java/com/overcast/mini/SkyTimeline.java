package com.overcast.mini;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/** One local-day elevation profile, deliberately based on TIME rather than compass bearings. */
public final class SkyTimeline {
    public final long dayStartMs;
    public final long dayEndMs;
    public final double[] sunAltitudes;
    public final double[] moonAltitudes;
    public final double nowProgress;
    public final SkyMath.Sky now;
    public final String sunrise;
    public final String sunset;
    public final String moonrise;
    public final String moonset;

    private SkyTimeline(long start, long end, double[] sun, double[] moon,
                        double progress, SkyMath.Sky current,
                        String sunrise, String sunset, String moonrise, String moonset) {
        dayStartMs = start;
        dayEndMs = end;
        sunAltitudes = sun;
        moonAltitudes = moon;
        nowProgress = progress;
        now = current;
        this.sunrise = sunrise;
        this.sunset = sunset;
        this.moonrise = moonrise;
        this.moonset = moonset;
    }

    public static SkyTimeline calculate(double latitude, double longitude,
                                        long nowMs, WeatherData weather) {
        TimeZone tz = TimeZone.getDefault();
        if (weather != null && weather.timezone != null && !weather.timezone.isEmpty()) {
            TimeZone resolved = TimeZone.getTimeZone(weather.timezone);
            // Prevent silently changing an unrecognised location zone to GMT.
            if (!"GMT".equals(resolved.getID()) || "GMT".equals(weather.timezone)
                    || "Etc/GMT".equals(weather.timezone)) tz = resolved;
        }
        Calendar day = Calendar.getInstance(tz);
        day.setTimeInMillis(nowMs);
        day.set(Calendar.HOUR_OF_DAY, 0);
        day.set(Calendar.MINUTE, 0);
        day.set(Calendar.SECOND, 0);
        day.set(Calendar.MILLISECOND, 0);
        long start = day.getTimeInMillis();
        SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        dateFmt.setTimeZone(tz);
        String date = dateFmt.format(day.getTime());
        day.add(Calendar.DAY_OF_MONTH, 1);
        long end = day.getTimeInMillis();

        // 10-minute-ish local-day samples; DST transition days are handled naturally.
        final int STEPS = 144;
        double[] sun = new double[STEPS + 1];
        double[] moon = new double[STEPS + 1];
        long[] time = new long[STEPS + 1];
        for (int i = 0; i <= STEPS; i++) {
            long ms = start + Math.round((end - start) * (i / (double) STEPS));
            time[i] = ms;
            SkyMath.Sky sky = SkyMath.calculate(latitude, longitude, ms);
            sun[i] = sky.sun.altitude;
            moon[i] = sky.moon.altitude;
        }

        // -0.83 degrees approximates atmospheric refraction + apparent solar radius.
        long riseSun = crossing(time, sun, -0.83, true);
        long setSun = crossing(time, sun, -0.83, false);
        long riseMoon = crossing(time, moon, 0, true);
        long setMoon = crossing(time, moon, 0, false);

        String sunrise = clock(riseSun, tz);
        String sunset = clock(setSun, tz);
        if (weather != null && date.equals(weather.forecastLocalDate)) {
            if (weather.sunrise != null && !weather.sunrise.equals("--:--")) sunrise = weather.sunrise;
            if (weather.sunset != null && !weather.sunset.equals("--:--")) sunset = weather.sunset;
        }
        return new SkyTimeline(start, end, sun, moon,
                Math.max(0, Math.min(1, (nowMs - start) / (double) (end - start))),
                SkyMath.calculate(latitude, longitude, nowMs),
                sunrise, sunset, clock(riseMoon, tz), clock(setMoon, tz));
    }

    private static long crossing(long[] time, double[] altitude, double horizon, boolean rising) {
        for (int i = 1; i < altitude.length; i++) {
            double a = altitude[i - 1] - horizon;
            double b = altitude[i] - horizon;
            if ((rising && a <= 0 && b > 0) || (!rising && a >= 0 && b < 0)) {
                double f = -a / (b - a);
                return time[i - 1] + Math.round((time[i] - time[i - 1]) * f);
            }
        }
        // At high latitudes there can be no rise/set on the chosen date.
        return -1;
    }

    private static String clock(long ms, TimeZone tz) {
        if (ms < 0) return "—";
        SimpleDateFormat fmt = new SimpleDateFormat("HH:mm", Locale.US);
        fmt.setTimeZone(tz);
        return fmt.format(ms);
    }
}

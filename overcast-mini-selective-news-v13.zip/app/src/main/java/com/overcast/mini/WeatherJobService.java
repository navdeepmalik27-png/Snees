package com.overcast.mini;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.appwidget.AppWidgetManager;

/**
 * Ultra-low-battery background updater using Android's Doze-friendly JobScheduler.
 * - Batches with OS network windows (15 min flex)
 * - Skips updates when offline or battery is low
 * - Zero wake locks, zero foreground service, zero background GPS
 */
public final class WeatherJobService extends JobService {
    private static final int JOB_PERIODIC = 101;
    private static final int JOB_IMMEDIATE = 102;
    private static final long MIN_REFRESH_GAP_MS = 30_000L; // 30s debounce

    private volatile boolean cancelled;

    public static void schedulePeriodic(Context context) {
        JobScheduler js = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        long intervalMs = Math.max(30, WeatherPrefs.getIntervalMinutes(context)) * 60_000L;
        long flexMs = Math.min(15 * 60_000L, intervalMs / 4);
        // Re-registering on every 30-minute astronomy redraw would indefinitely
        // postpone a 2-hour weather job. Keep the existing schedule if unchanged.
        JobInfo pending = js.getPendingJob(JOB_PERIODIC);
        if (pending != null && pending.getIntervalMillis() == intervalMs) return;
        JobInfo job = new JobInfo.Builder(JOB_PERIODIC, new ComponentName(context, WeatherJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresBatteryNotLow(true)
                .setPeriodic(intervalMs, flexMs)
                .setPersisted(true)
                .build();
        js.schedule(job);
    }

    public static void triggerNow(Context context, boolean force) {
        if (!WeatherPrefs.hasLocation(context)) return;
        long age = System.currentTimeMillis() - WeatherPrefs.getLastUpdatedMs(context);
        if (!force && age < MIN_REFRESH_GAP_MS) {
            WidgetRenderer.updateAll(context);
            return;
        }
        JobScheduler js = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        JobInfo job = new JobInfo.Builder(JOB_IMMEDIATE, new ComponentName(context, WeatherJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setOverrideDeadline(10_000L)
                .build();
        js.schedule(job);
    }

    /** Keep network refreshes running if a home widget OR the optional status indicator needs them. */
    public static void cancelWhenUnused(Context context) {
        if (WeatherPrefs.isTemperatureBadgeEnabled(context)) return;
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        Class<?>[] providers = {OvercastWidgetProvider.class, OvercastForecastWidgetProvider.class,
                OvercastAqiWidgetProvider.class, OvercastPrecipWidgetProvider.class,
                OvercastSkyWidgetProvider.class, OvercastNewsWidgetProvider.class};
        for (Class<?> provider : providers) {
            if (manager.getAppWidgetIds(new ComponentName(context, provider)).length > 0) return;
        }
        cancelAll(context);
    }

    public static void cancelAll(Context context) {
        JobScheduler js = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js != null) js.cancelAll();
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        if (!WeatherPrefs.hasLocation(this)) return false;
        cancelled = false;
        new Thread(() -> {
            try {
                double lat = WeatherPrefs.getLat(this);
                double lon = WeatherPrefs.getLon(this);
                boolean fahrenheit = WeatherPrefs.isFahrenheit(this);
                String json = OpenMeteoClient.fetchForecastJson(lat, lon, fahrenheit);
                boolean matchingLocation = lat == WeatherPrefs.getLat(this)
                        && lon == WeatherPrefs.getLon(this);
                if (!cancelled && matchingLocation && fahrenheit == WeatherPrefs.isFahrenheit(this)
                        && WeatherData.parse(json) != null) {
                    WeatherPrefs.saveCache(this, json, System.currentTimeMillis());
                }
                if (!cancelled) {
                    String aqiJson = OpenMeteoClient.fetchAirQualityJson(lat, lon);
                    if (!cancelled && lat == WeatherPrefs.getLat(this)
                            && lon == WeatherPrefs.getLon(this)
                            && AirQualityData.parse(aqiJson) != null) {
                        WeatherPrefs.saveAirQualityCache(this, aqiJson, System.currentTimeMillis());
                    }
                    if (!cancelled) {
                        WidgetRenderer.updateAll(this);
                        WeatherStatusManager.sync(this);
                        WeatherTileService.requestRefresh(this);
                    }
                }
            } finally {
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        cancelled = true;
        return false; // do not aggressively retry; wait for next OS window
    }
}

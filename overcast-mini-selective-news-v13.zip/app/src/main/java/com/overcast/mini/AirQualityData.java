package com.overcast.mini;

import org.json.JSONObject;

/** Air quality from the Open-Meteo / CAMS atmospheric model. US AQI, NOT India's CPCB AQI. */
public final class AirQualityData {
    public final int usAqi;
    public final double pm25;
    public final double pm10;

    private AirQualityData(int usAqi, double pm25, double pm10) {
        this.usAqi = usAqi;
        this.pm25 = pm25;
        this.pm10 = pm10;
    }

    public static AirQualityData parse(String json) {
        if (json == null || json.isEmpty()) return null;
        try {
            JSONObject root = new JSONObject(json);
            JSONObject current = root.optJSONObject("current");
            if (current == null || current.isNull("us_aqi")) return null;
            double aqi = current.optDouble("us_aqi", Double.NaN);
            if (Double.isNaN(aqi) || Double.isInfinite(aqi) || aqi < 0) return null;
            return new AirQualityData((int) Math.round(aqi),
                    current.optDouble("pm2_5", Double.NaN),
                    current.optDouble("pm10", Double.NaN));
        } catch (Exception e) {
            return null;
        }
    }

    public String label() {
        if (usAqi <= 50) return "Good";
        if (usAqi <= 100) return "Moderate";
        if (usAqi <= 150) return "Sensitive groups";
        if (usAqi <= 200) return "Unhealthy";
        if (usAqi <= 300) return "Very unhealthy";
        return "Hazardous";
    }

    /** Colors follow the familiar US AQI category palette. */
    public int categoryColor() {
        if (usAqi <= 50) return 0xff24835c;
        if (usAqi <= 100) return 0xffa07800;
        if (usAqi <= 150) return 0xffbc5c18;
        if (usAqi <= 200) return 0xffbb3347;
        if (usAqi <= 300) return 0xff8752a4;
        return 0xff87415b;
    }

    public static String pollutantLabel(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return "--";
        return value < 10 ? String.format(java.util.Locale.US, "%.1f", value)
                : Integer.toString((int) Math.round(value));
    }
}

package com.overcast.mini;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/** Validates article URLs before handing them to the user's browser. */
public final class NewsLinkActivity extends Activity {
    public static final String EXTRA_URL = "article_url";
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String url = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_URL);
        if (NewsFeedClient.isPublisherLink(url)) {
            try {
                Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                view.addCategory(Intent.CATEGORY_BROWSABLE);
                startActivity(view);
            } catch (ActivityNotFoundException ignored) { }
        }
        finish();
    }
}

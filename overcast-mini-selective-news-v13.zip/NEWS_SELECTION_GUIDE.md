# Selective Headlines in Overcast Mini v1.3

## Choose your news sections
1. Open **Overcast Mini** (or tap the city label in its weather/news widget).
2. Scroll to **The Hindu · News selection**.
3. Enable any combination of:
   - **Science**: The Hindu science RSS
   - **World / International**: The Hindu international news RSS
   - **Top Stories (home feed)**: The Hindu website home RSS
4. Tap **Save & Update**. A news-only change does not require doing a new city lookup when a weather location is already saved.
5. The **Weather + Selective News** widget retains the existing weather display and cycles headlines from the selected feeds. Each item is tagged with its section and opens the original publisher article.

All three are selected initially. You can turn off all three if you want only weather in that widget; RSS polling will stop.

## Important distinction: Top Stories vs printed Page One
The Hindu home RSS has general current homepage headlines, **not a verified RSS listing for the printed newspaper's Page One**. This is deliberately labelled "Top Stories" in the app, rather than representing it as print Page One.

## How often it refreshes
When the widget exists and at least one feed is enabled, `JobScheduler` requests a fetch every ~30 minutes (Android's Doze/battery rules can delay it). Up to 12 headline titles and original links are cached on-device. Data from different selected feeds are interleaved and duplicate article links are removed. Feed failures leave cached information available; old feeds are filtered out when you uncheck a section.

## GitHub ZIP build
1. Upload **overcast-mini-selective-news-v13.zip** to the root of `navdeepmalik27-png/cht`.
2. Replace `.github/workflows/build.yml` with the **build-selective-news.yml** supplied alongside the ZIP (use the file's contents, but keep the repository path `.github/workflows/build.yml`).
3. Commit and run **Build Overcast Mini APK** in GitHub Actions.
4. Download the `overcast-mini-selective-news-apk` artifact.

> The full APK build has not been performed locally. The GitHub workflow needs to be run to verify Android SDK compilation and real feed accessibility on the phone. Use the same signing keystore as your existing installed APK for seamless upgrades.

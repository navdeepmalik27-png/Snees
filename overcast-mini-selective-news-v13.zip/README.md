# Overcast Mini — Weather, AQI, Sky Arcs, News & Quick Settings

A zero-dependency Android widget pack styled after the open-source **[Overcast](https://github.com/sameerasw/overcast)** Material 3 Expressive design language and powered by the free **[Open-Meteo API](https://open-meteo.com/en/docs)** (no API key required).

## Lightweight by Design (vs. ~6.75 MB full app)
- **Zero external libraries**: Pure Java 11 + Android Framework SDK only (no Kotlin stdlib, no Jetpack Compose, no AndroidX, no Material library, no OkHttp, no Gson, no WorkManager).
- **Native Material 3 Expressive Dynamic Color**: Uses Android 12+ system dynamic color tokens (`@android:color/system_accent1_*`, `@android:color/system_neutral1_*`) directly in XML (`values-v31` / `values-night-v31`) with matching Overcast dark/light tonal fallbacks for Android 8–11.
- **Minimal Vector Icons**: 8 geometric `VectorDrawable` XMLs (~250 bytes each) covering all WMO weather codes.

## Battery-Saving Architecture
- **No background GPS / location polling**: Saves coordinates once via Open-Meteo Geocoding or an optional one-shot cached coarse location (`NETWORK_PROVIDER` / `PASSIVE_PROVIDER`).
- **Doze-friendly `JobScheduler`**: Batches updates with OS network windows (`NETWORK_TYPE_ANY`, `setRequiresBatteryNotLow(true)`, configurable 1h / 2h / 3h / 6h interval, `updatePeriodMillis="0"`).
- **Compact gzipped payloads**: Requests the next eight hourly weather records, two days of sunrise/sunset, and a small separate AQI response. Both are cached for all widget types.
- **Zero wake locks, zero foreground services, 30s tap-to-refresh debounce**.

## Widgets Included
1. **Overcast · Compact (2×2+)**: Expressive rounded card (`28dp` radius), location pill, rain probability pill, oversized display temperature (`50sp` bold), crisp vector weather icon, condition + H/L temperatures.
2. **Overcast · Forecast Pill (4×2+)**: Adds a nested Material 3 Expressive tonal inner card (`20dp` radius) showing the next 4 hourly forecast slots.
3. **Overcast · Air Quality (2×2+)**: Current **US AQI** category, PM2.5/PM10 in µg/m³, and the age of the cached report. Category colors follow the US AQI scale. Uses **Open-Meteo / CAMS modelled concentrations**, not a nearby physical monitor and **not** India's CPCB AQI scale.
4. **Overcast · Precipitation (4×2+)**: Next-six-hour precipitation estimate in mm, highest hourly probability, and six color bars showing rain chance (local hourly timestamps).
5. **Overcast · Sun & Moon (4×3+)**: A visual **24-hour sky arc** (amber sun trajectory, blue dashed moon trajectory, and a NOW marker). The curves show altitude above/below the horizon, **not compass directions**. Shows sunrise, sunset, moonrise, moonset, moon phase, and illumination. Solar/lunar positions and lunar rise/set times are calculated **locally** every ~30 minutes. Sunrise/sunset uses Open-Meteo when today's local data is available. No navigation-grade accuracy is claimed.

6. **Overcast · Weather + Selective News (4×2+)**: A separate weather-and-news hybrid with current city, icon, temperature, and condition above an automatic rotating ticker for selected **The Hindu · Science, World, and Top Stories** headlines. Each headline opens its original publisher URL when tapped. Existing compact, forecast, AQI, rain and sky widgets stay unchanged. The weather row can be tapped to refresh weather and headlines; tapping the city pill opens setup.

### The Hindu selective RSS headlines (v1.3)
- The **Weather + Selective News** widget retains the existing city/temperature/weather display. The app settings have three independent checkboxes, defaulting to **all on**: **Science**, **World / International**, **Top Stories (Home)**. You can choose one, two, all three, or none (which pauses RSS updates).
- Science: `https://www.thehindu.com/sci-tech/science/feeder/default.rss`.
- World / International: `https://www.thehindu.com/news/international/feeder/default.rss`.
- Top Stories: `https://www.thehindu.com/feeder/default.rss`. **This is The Hindu's HOME feed, not a verified reproduction of print Page One headlines.** There is no reliable official Page One-specific RSS feed verified here.
- The app polls **only the selected feeds** approximately every 30 minutes while the news widget is installed (Android may delay polling). It interleaves up to 12 combined headlines from the selected categories, deduplicates article URLs, and labels each with its category. Partial feed failures do not discard successful feeds. No article body is stored.
- The existing publisher-only HTTPS validation and direct links remain. An all-off setting leaves the weather half available and cancels RSS jobs. The existing v1.2 cache is not silently reclassified; it will refill from the new feeds after the next refresh.
- No API key or additional libraries. Real-world feed accessibility can depend on publisher rate limits, protections and terms; verify on the device. Public distribution should respect The Hindu's RSS terms and attribution requirements.

## Quick Settings Weather Tile + Opt-in Status Bar Weather Icons
- **Android 8+**: Native swipe-down `Weather` Quick Settings toggle. Its label includes the cached current temperature, e.g. `Weather 27°C`. The tile displays a condition/temperature icon from the set supplied by the user.
- **Indicator ON**: Posts **one quiet ongoing notification**. The left-hand status-bar symbol changes between nine supplied weather illustrations, using white/transparent small icon assets at 24/36/48/72/96 px for Android density scaling. The **colored original artwork** appears as the enlarged notification icon when supported. The notification text also includes current temperature, condition, and city.
- **Indicator OFF**: Cancels the notification immediately. Removing the Quick Settings tile also disables the indicator. There is a `Turn off` action in the notification. It restores the enabled state after reboot where Android permits.
- **No extra network calls**: The symbols update when the existing shared weather cache is refreshed (1/2/3/6-hour user-selected schedule), or when the tile is toggled. An indicator with a stale/unavailable forecast switches to a generic mild icon and states that weather is unavailable instead of showing a falsely fresh reading.
- **Permission**: Android 13+ requires `Allow notifications`; disabling the app's weather notification channel also hides the indicator.
- **Add the tile**: Open Overcast Mini and choose `Add Weather Quick Settings tile` (Android 13+ confirmation prompt) or swipe down twice → Edit tiles → add the Weather tile manually.
- **Android limitation**: Android notification **small icons are monochrome**, usually tinted white or dark by the OS; the uploaded colors **cannot appear in the status bar** without OS-specific privileges. The enlarged colored image appears in the notification drawer. Exact placement next to the time is controlled by OxygenOS and **cannot be guaranteed**. Official references: [Android system bars](https://developer.android.com/design/ui/mobile/guides/foundations/system-bars) and [Notification.Builder.setSmallIcon](https://developer.android.com/reference/android/app/Notification.Builder#setSmallIcon(int)).

### Status-bar artwork mapping
The images received here were named `10001558xx.png`/`.jpg` by the upload system, so their original temperature-range filenames **were not available**. These are editable defaults, implemented in `WeatherStatusIcons.choose()`:

| Priority / temperature in °C | Status-bar artwork |
| --- | --- |
| Thunderstorm/hail (WMO 95–99), any temperature | Gray storm cloud with rain and lightning |
| Rain/drizzle/showers (WMO 51–67 or 80–82), any temperature | Blue rain cloud |
| Any other weather, ≤ 0°C | Guy with meter / bundled-up person |
| 1–7°C | Two snowflakes |
| 8–13°C | One snowflake |
| 14–20°C | Sun and cloud |
| 21–27°C | Simple thermometer |
| 28–33°C | Simple thermometer (chosen warm fallback for the unspecified slot) |
| 34–38°C | Guy sweating |
| ≥ 39°C | Red hot flame icon |

Weather condition has precedence over temperature for heavy rain and thunderstorms. Thresholds are always converted to Celsius internally if Fahrenheit units are selected. Since no separate night-specific original was supplied, normal/mild nights reuse the same sun-and-cloud illustration. Only one condition is shown at a time.


## How to Build the APK

### Option 1: Direct Android SDK build (requires Android SDK + JDK 11+)
```bash
chmod +x build_min_apk.sh
./build_min_apk.sh
# Output: build_min/overcast-mini-widget.apk
```

### Option 2: Zero Local Setup (GitHub Actions)
Push this folder to a GitHub repository -> open the **Actions** tab -> run **Build Overcast Mini APK** -> download `overcast-mini-selective-news-apk`. An Android SDK build runner is required; the source ZIP itself is not an installable APK.

### Option 3: Android Studio / Gradle
Open this folder in Android Studio and run **Build -> Generate Signed App Bundle / APK** (or `./gradlew assembleRelease`).

## How to Use
1. Install the built APK, then long-press your Android home screen and open **Widgets**.
2. Choose any of the six **Overcast Mini** widgets. Place it on the home screen.
3. Set the city by name or use a cached coarse location, then save. **All six widgets and the Weather Quick Settings tile share one chosen weather location.** Tap the location label on a widget to change it.
4. Tap the card to request a weather/AQI refresh. The AQI and precipitation widgets use the same battery-friendly scheduled update interval as the original weather widgets.
5. Open the app and add the Quick Settings Weather tile. Swipe down to toggle the status-bar temperature on/off. On Android 13+, allow notifications when requested.

## Data & Accuracy
- Forecasts, rainfall, sunrise/sunset: [Open-Meteo Forecast API](https://open-meteo.com/en/docs).
- Modelled air quality: [Open-Meteo Air Quality API](https://open-meteo.com/en/docs/air-quality-api), powered by [Copernicus Atmosphere Monitoring Service (CAMS)](https://atmosphere.copernicus.eu/). **US AQI is not directly interchangeable with India CPCB AQI; neither should be mistaken for nearby station readings.**
- Sun/moon sky arc: offline approximate solar/lunar ephemeris. The chart plots elevation against the chosen city's local time (not azimuth/compass), and the moonrise/moonset labels are approximate. The lunar position omits high-accuracy corrections (parallax, perturbation series, and atmospheric refraction), so expect errors of several minutes or more for rise/set and a few degrees for positions. Use a precise astronomy app for observations/navigation.
- The sky-arc chart redraws at Android's ~30-minute widget interval. Android may delay updates during Doze/battery saver; positions are not continuously animated. If forecast timezone information isn't cached yet, the chart temporarily falls back to the device's own timezone until forecast data loads.
- Network-dependent widgets show placeholders until a city is chosen and data are fetched. AQI reports older than six hours are visibly labelled as stale, not passed off as live measurements.

## Resource Notes
No new dependencies. The tiny rain and sky illustrations are rendered into low-resolution bitmap charts only when a widget updates. The nine user-supplied status bar glyphs are pre-rendered white/alpha PNG resources; no dynamic bitmaps or extra CPU work are required to produce the notification icon. No foreground services or ongoing location polling.

### Build/test status
The source ZIP is ready for the included Android SDK CLI / GitHub Actions build, but **no actual device or full Android SDK compilation was available in the editing environment**. XML resources and pure-Java sky calculations were validated; verify OxygenOS status-bar icon rendering and tile add flows on the target device.

### Weather + News update notes
- Add the **Overcast · Weather + Selective News** widget from the home-screen widget picker. Choose Science, World and/or Top Stories in app settings for automatic cycling (where supported by your launcher).
- RSS updates are separate from the weather schedule. The weather icon/temperature and quick-settings/status-bar functionality continue using the existing Open-Meteo cache.
- The source archive is named `overcast-mini-selective-news-v13.zip`; use the accompanying `build.yml` in `.github/workflows/` when the repository stores only that ZIP (as in your existing GitHub setup).
- For updating an APK already installed on your phone, retain the same signing keystore. The included minimal build script generates an ephemeral debug key by default, so APKs built in separate runs may require uninstall/reinstall, which can remove saved local widget settings. For reproducible signing in future builds, configure GitHub Actions repository secrets `OVERCAST_KEYSTORE_B64`, `OVERCAST_KEYSTORE_PASS`, `OVERCAST_KEY_ALIAS`, optionally `OVERCAST_KEY_PASS`, using a securely stored private keystore. Never commit the keystore/private key to a public repository. A newly chosen key cannot update an app previously signed with a different key.
